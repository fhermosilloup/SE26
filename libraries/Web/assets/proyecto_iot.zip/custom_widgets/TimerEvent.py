
import tkinter as tk
import json
import re


class TimerEvent:
    default_props = {
        "label": "Temporizador",
        "period_ms": "1000",
        "autostart": "True",
    }

    custom_properties = [
        {"name": "label", "label": "Título del Temporizador:", "type": "text"},
        {
            "name": "period_ms",
            "label": "Periodo del temporizador (ms):",
            "type": "text",
        },
        {
            "name": "autostart",
            "label": "Iniciar automáticamente:",
            "type": "boolean",
        },
    ]

    supported_events = ["on_timer"]
    
    value_help = {
        "soportado": True,
        "tipo": "Dict o String JSON",
        "valores": "{'action': 'start' | 'stop', 'period_ms': int >= 1}",
        "desc": "Temporizador que corre en el navegador y emite el evento on_timer cada "
                "'period_ms' milisegundos. Desde Python puedes iniciarlo, detenerlo o cambiar "
                "su periodo. Ambas claves son opcionales y se pueden combinar.",
        "ejemplos": [
            "ui.set_value('{id}', {'action': 'start'})",
            "ui.set_value('{id}', {'action': 'stop'})",
            "ui.set_value('{id}', {'period_ms': 500})",
            "ui.set_value('{id}', {'period_ms': 2000, 'action': 'start'})",
            "ui.set_property('{id}', 'period_ms', 250)",
        ],
        "envia": "on_timer a {'period_ms': int, 'timestamp': milisegundos Unix}",
        "notas": [
            "Debes conectar el evento on_timer (clic derecho > Connect) para recibir los ticks.",
            "Ejemplo de handler: def on_timer(context): ts = context['value']['timestamp']",
            "Un número suelto (ej. 500) se ignora. Manda siempre un Dict: {'period_ms': 500}.",
            "Si cambias 'period_ms' con el timer corriendo, se reinicia con el nuevo periodo.",
            "Un periodo no numérico o menor a 1 se rechaza con error en la consola del navegador.",
            "'Iniciar automáticamente' solo se lee al cargar la página.",
            "El timer vive en el navegador: solo emite mientras haya una pestaña abierta, y cada pestaña abierta emite sus propios ticks.",
            "El widget es invisible en el dashboard exportado.",
        ],
    }

    def __init__(self, width=1, height=1):
        self.width = width
        self.height = height
        self.props = self.default_props.copy()
    
    def to_dict(self):
        return {
            "id": getattr(self, 'id', "w_0"),
            "type": getattr(self, 'type', self.__class__.__name__),
            "x": getattr(self, 'x', 50),
            "y": getattr(self, 'y', 50),
            "width": getattr(self, 'width', getattr(self, 'default_props', {}).get('width', 300)),
            "height": getattr(self, 'height', getattr(self, 'default_props', {}).get('height', 150)),
            # IMPORTANTE: Aseguramos que se guarde el diccionario de propiedades actual de la instancia
            "props": getattr(self, 'props', {}),
            "events": getattr(self, 'events', {})
        }
        
    def render_canvas(self, canvas, x, y):
        # Widget invisible en el diseñador.
        box=canvas.create_rectangle(x, y, x+self.width, y+self.height, fill="#234764", outline="#334155", width=1)
        text=canvas.create_text(x+self.width/2, y + self.height/2, text="TimerEvent", fill="#ffffff", font=("Segoe UI", 9))
        return [box,text]

    def render_html(self, w_id, props):
        # Unificar propiedades de forma segura para evitar errores si props es None
        p = {**self.default_props, **(props or {})}

        orig_id = str(w_id)
        safe_id = re.sub(r"\W", "_", orig_id)

        try:
            period_ms = max(
                1, int(p.get("period_ms", self.default_props.get("period_ms", 1000)))
            )
        except (ValueError, TypeError):
            period_ms = 1000

        autostart = str(
            p.get("autostart", self.default_props.get("autostart", "True"))
        ).strip().lower() not in (
            "false", "0", "no", "off"
        )

        cfg = json.dumps({
            "id": orig_id,
            "period_ms": period_ms,
            "autostart": autostart
        })

        return f"""
        <div id="timer_{safe_id}" style="display:none;"></div>

        <script>
        (function() {{
            const cfg = {cfg};

            let period = cfg.period_ms;
            let timerId = null;
            let running = false;

            function emitTick() {{
                if (typeof emitEvent === "function") {{
                    emitEvent(
                        {{ id: cfg.id }},
                        "on_timer",
                        {{
                            period_ms: period,
                            timestamp: Date.now()
                        }}
                    );
                }}
            }}

            function start() {{
                if (running) return;

                running = true;
                timerId = setInterval(emitTick, period);
            }}

            function stop() {{
                if (timerId !== null) {{
                    clearInterval(timerId);
                    timerId = null;
                }}

                running = false;
            }}

            function setPeriod(ms) {{
                const value = Number(ms);

                if (!Number.isFinite(value) || value < 1) {{
                    throw new Error(
                        "El periodo debe ser un número positivo en ms."
                    );
                }}

                period = Math.floor(value);

                // Si está activo, reinicia el intervalo con el nuevo periodo.
                if (running) {{
                    stop();
                    start();
                }}
            }}

            function update(value) {{
                if (typeof value === "string") {{
                    try {{
                        value = JSON.parse(value);
                    }} catch (e) {{
                        return;
                    }}
                }}

                if (!value || typeof value !== "object") return;

                if (value.period_ms !== undefined) {{
                    setPeriod(value.period_ms);
                }}

                if (value.action === "start") start();
                else if (value.action === "stop") stop();
            }}

            // API para el sistema de widgets del dashboard.
            window.__widgets = window.__widgets || {{}};

            window.__widgets[cfg.id] = {{
                update: update,
                update_prop: function(prop, value) {{
                    if (prop === "period_ms") {{
                        setPeriod(value);
                    }}
                }},
                start: start,
                stop: stop,
                set_period: setPeriod
            }};

            // Permite controlar el temporizador mediante mensajes update.
            if (typeof socket !== "undefined") {{
                socket.on("update", function(data) {{
                    if (data && data.id === cfg.id) {{
                        update(data.value);
                    }}
                }});
            }}

            if (cfg.autostart) start();

        }})();
        </script>
        """
